from flask import Flask, request, render_template
from pickle import load
import numpy as np

app = Flask(__name__)

# Load the model from the pickle file
with open("CPP.pkl", "rb") as f:
    model = load(f)

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/predict', methods=['POST'])
def predict():
    # Get the input data from the form
    car_name = request.form['car_name']
    year = int(request.form['year'])
    present_price = float(request.form['present_price'])
    kms_driven = int(request.form['kms_driven'])
    fuel_type = int(request.form['fuel_type'])
    seller_type = int(request.form['seller_type'])
    transmission = int(request.form['transmission'])
    owner = int(request.form['owner'])

    # Perform prediction using the loaded model
    input_data = [[year, present_price, kms_driven, fuel_type, seller_type, transmission, owner]]
    prediction = model.predict(input_data)
    predicted_price = round(prediction[0][0], 2)

    # Translate categorical codes to meaningful text
    fuel_type_text = ["CNG", "Diesel", "Petrol"][fuel_type]
    seller_type_text = ["Dealer", "Individual"][seller_type]
    transmission_text = ["Automatic", "Manual"][transmission]
    owner_text = ["First", "Second"]

    # Prepare the message for rendering
    msg = f"Predicted Selling Price for {car_name}: ₹{predicted_price} Lakhs"

    return render_template("home.html", msg=msg)

if __name__ == "__main__":
    app.run(debug=True)
